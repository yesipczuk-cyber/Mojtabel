МОЙ ТАБЕЛЬ — исходный проект Android

В проекте уже находится приложение учёта рабочего времени:
- ввод начала и окончания смены;
- ночные смены через полночь;
- перерывы не вычитаются;
- ставка 25 zł brutto/час;
- итоги за месяц и экспорт CSV;
- локальное сохранение данных на устройстве.

КАК СОБРАТЬ APK
1. Установите Android Studio на компьютер: https://developer.android.com/studio
2. Распакуйте архив MojTabel.zip.
3. В Android Studio выберите Open и укажите папку MojTabel.
4. Дождитесь Gradle Sync и установки Android SDK Platform 35 (если Android Studio предложит).
5. Выберите Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK появится в app/build/outputs/apk/debug/app-debug.apk.
7. Перенесите APK на телефон Android и установите. При необходимости разрешите установку приложений из этого источника.

Примечание: этот архив — проект для сборки, не готовый APK. Для сборки нужен Android Studio/Android SDK.
